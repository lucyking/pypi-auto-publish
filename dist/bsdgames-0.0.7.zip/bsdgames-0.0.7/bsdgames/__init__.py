import _pom
def main():
    """Entry point for the application script"""
    print("Call your main application code here")
def pom():
    _pom.Pom()

